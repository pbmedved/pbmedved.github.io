import "../../mi-band7/index"
