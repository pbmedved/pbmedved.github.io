 # zeppos Watchface for Watchdrip for GTR3 Pro
 <p align="center">
 <img src="https://raw.githubusercontent.com/bigdigital/zeppos_watchdrip_timer_wf/5d58da9cf91b96d08a0c451307865db9d05610df/assets/gtr-3-pro/images/preview.png" alt="Watchface preview"/>
 </p>
 This repository contains a watchface which is designed to work together with watch <a href="https://github.com/bigdigital/zeppos_watchdrip_app">Companion APP</a>  and Android phone Watchdrip application (see the latest version on <a href="https://www.patreon.com/xdrip_miband">Patreon page</a>). 
 The watchface can display a dynamic data from the Android phone Watchdrip application by usin ZEPP OS fetch API.

