AppSideService({
  //this is a fake declaration. the side app code defined in zepp companion application
  onInit() {},
  onRun() {},
  onDestroy() {},
});
